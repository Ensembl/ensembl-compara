-- MySQL dump 9.11
--
-- Host: ia64f    Database: ensembl_compara_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `domain`
--

CREATE TABLE domain (
  domain_id int(10) NOT NULL auto_increment,
  stable_id varchar(40) NOT NULL default '',
  source_id int(10) NOT NULL default '0',
  description varchar(255) default NULL,
  PRIMARY KEY  (domain_id),
  UNIQUE KEY source_id (source_id,stable_id)
) TYPE=MyISAM;
