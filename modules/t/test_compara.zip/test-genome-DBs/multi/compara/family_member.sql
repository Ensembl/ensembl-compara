-- MySQL dump 9.11
--
-- Host: ia64f    Database: ensembl_compara_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `family_member`
--

CREATE TABLE family_member (
  family_id int(10) NOT NULL default '0',
  member_id int(10) NOT NULL default '0',
  cigar_line mediumtext,
  UNIQUE KEY family_id (family_id,member_id),
  UNIQUE KEY member_id (member_id,family_id)
) TYPE=MyISAM;
