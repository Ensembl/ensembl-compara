# MySQL dump 8.10
#
# Host: ecs1d    Database: arne_compara_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'genomic_align_block'
#

CREATE TABLE genomic_align_block (
  consensus_dnafrag_id int(10) DEFAULT '0' NOT NULL,
  consensus_start int(10) DEFAULT '0' NOT NULL,
  consensus_end int(10) DEFAULT '0' NOT NULL,
  query_dnafrag_id int(10) DEFAULT '0' NOT NULL,
  query_start int(10) DEFAULT '0' NOT NULL,
  query_end int(10) DEFAULT '0' NOT NULL,
  query_strand tinyint(4) DEFAULT '0' NOT NULL,
  score double,
  perc_id int(10),
  cigar_line mediumtext,
  KEY query_dnafrag_id (query_dnafrag_id,query_start,query_end),
  KEY query_dnafrag_id_2 (query_dnafrag_id,query_end),
  KEY consensus_idx (consensus_dnafrag_id,consensus_start,consensus_end,query_dnafrag_id)
);
