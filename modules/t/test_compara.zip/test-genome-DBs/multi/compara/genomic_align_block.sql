-- MySQL dump 9.11
--
-- Host: ia64f    Database: ensembl_compara_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `genomic_align_block`
--

CREATE TABLE genomic_align_block (
  consensus_dnafrag_id int(10) NOT NULL default '0',
  consensus_start int(10) NOT NULL default '0',
  consensus_end int(10) NOT NULL default '0',
  query_dnafrag_id int(10) NOT NULL default '0',
  query_start int(10) NOT NULL default '0',
  query_end int(10) NOT NULL default '0',
  query_strand tinyint(4) NOT NULL default '0',
  method_link_id int(10) NOT NULL default '0',
  score double default NULL,
  perc_id int(10) default NULL,
  cigar_line mediumtext,
  group_id int(10) NOT NULL default '0',
  level_id int(10) NOT NULL default '0',
  strands_reversed tinyint(1) NOT NULL default '0',
  KEY consensus_idx (consensus_dnafrag_id,method_link_id,consensus_start,consensus_end,query_dnafrag_id),
  KEY query_dnafrag_id (query_dnafrag_id,method_link_id,query_start,query_end),
  KEY query_dnafrag_id_2 (query_dnafrag_id,method_link_id,query_end)
) TYPE=MyISAM;
