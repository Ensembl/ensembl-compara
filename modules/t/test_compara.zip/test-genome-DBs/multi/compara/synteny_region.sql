# MySQL dump 8.10
#
# Host: ecs1d    Database: arne_compara_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'synteny_region'
#

CREATE TABLE synteny_region (
  synteny_region_id int(10) NOT NULL auto_increment,
  rel_orientation tinyint(1) DEFAULT '1' NOT NULL,
  PRIMARY KEY (synteny_region_id)
);
