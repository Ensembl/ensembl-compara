-- MySQL dump 9.11
--
-- Host: ia64f    Database: ensembl_compara_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `family`
--

CREATE TABLE family (
  family_id int(10) NOT NULL auto_increment,
  stable_id varchar(40) NOT NULL default '',
  source_id int(10) NOT NULL default '0',
  description varchar(255) default NULL,
  description_score double default NULL,
  PRIMARY KEY  (family_id),
  UNIQUE KEY stable_id (stable_id),
  KEY description (description)
) TYPE=MyISAM;
