-- MySQL dump 9.11
--
-- Host: ia64f    Database: ensembl_compara_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `source`
--

CREATE TABLE source (
  source_id int(10) NOT NULL auto_increment,
  source_name varchar(40) NOT NULL default '',
  PRIMARY KEY  (source_id),
  UNIQUE KEY source_name (source_name)
) TYPE=MyISAM;
