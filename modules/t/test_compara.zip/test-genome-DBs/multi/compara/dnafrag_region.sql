-- MySQL dump 9.11
--
-- Host: ia64f    Database: ensembl_compara_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `dnafrag_region`
--

CREATE TABLE dnafrag_region (
  synteny_region_id int(10) NOT NULL default '0',
  dnafrag_id int(10) NOT NULL default '0',
  seq_start int(10) unsigned NOT NULL default '0',
  seq_end int(10) unsigned NOT NULL default '0',
  UNIQUE KEY unique_synteny (synteny_region_id,dnafrag_id),
  UNIQUE KEY unique_synteny_reversed (dnafrag_id,synteny_region_id)
) TYPE=MyISAM;
