# MySQL dump 8.10
#
# Host: ecs1d    Database: arne_compara_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'method_link_species'
#

CREATE TABLE method_link_species (
  method_link_id int(10),
  genome_db_id int(10),
  UNIQUE method_link_id (method_link_id,genome_db_id)
);
