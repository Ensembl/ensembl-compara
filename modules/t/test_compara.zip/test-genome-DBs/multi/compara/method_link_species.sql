-- MySQL dump 9.11
--
-- Host: ia64f    Database: ensembl_compara_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `method_link_species`
--

CREATE TABLE method_link_species (
  method_link_id int(10) default NULL,
  species_set int(10) default NULL,
  genome_db_id int(10) default NULL,
  KEY method_link_id (method_link_id,species_set,genome_db_id)
) TYPE=MyISAM;
