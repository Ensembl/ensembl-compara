# MySQL dump 8.10
#
# Host: ecs1d    Database: arne_compara_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'gene_relationship_member'
#

CREATE TABLE gene_relationship_member (
  gene_relationship_id int(10),
  genome_db_id int(10),
  member_stable_id varchar(40),
  chrom_start int(10),
  chrom_end int(10),
  chromosome varchar(10),
  KEY gene_relationship_id (gene_relationship_id),
  KEY member_stable_id (member_stable_id)
);
