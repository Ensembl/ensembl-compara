-- MySQL dump 9.11
--
-- Host: ia64f    Database: ensembl_compara_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `sequence`
--

CREATE TABLE sequence (
  sequence_id int(10) NOT NULL auto_increment,
  sequence mediumtext,
  length int(10) default NULL,
  PRIMARY KEY  (sequence_id)
) TYPE=MyISAM;
