-- MySQL dump 9.11
--
-- Host: ia64f    Database: ensembl_compara_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `member`
--

CREATE TABLE member (
  member_id int(10) NOT NULL auto_increment,
  stable_id varchar(40) NOT NULL default '',
  version int(10) default '0',
  source_id int(10) NOT NULL default '0',
  taxon_id int(10) NOT NULL default '0',
  genome_db_id int(10) default NULL,
  sequence_id int(10) default NULL,
  description varchar(255) default NULL,
  chr_name varchar(40) default NULL,
  chr_start int(10) default NULL,
  chr_end int(10) default NULL,
  chr_strand tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (member_id),
  UNIQUE KEY source_id (source_id,stable_id),
  KEY sequence_id (sequence_id)
) TYPE=MyISAM;
