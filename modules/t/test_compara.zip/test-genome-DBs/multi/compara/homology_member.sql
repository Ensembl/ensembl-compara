-- MySQL dump 9.11
--
-- Host: ia64f    Database: ensembl_compara_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `homology_member`
--

CREATE TABLE homology_member (
  homology_id int(10) NOT NULL default '0',
  member_id int(10) NOT NULL default '0',
  peptide_member_id int(10) default NULL,
  cigar_line mediumtext,
  cigar_start int(10) default NULL,
  cigar_end int(10) default NULL,
  perc_cov int(10) default NULL,
  perc_id int(10) default NULL,
  perc_pos int(10) default NULL,
  UNIQUE KEY member_id (member_id,homology_id),
  UNIQUE KEY homology_id (homology_id,member_id)
) TYPE=MyISAM;
