-- MySQL dump 9.11
--
-- Host: ia64f    Database: ensembl_compara_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `homology`
--

CREATE TABLE homology (
  homology_id int(10) NOT NULL auto_increment,
  stable_id varchar(40) default NULL,
  source_id int(10) NOT NULL default '0',
  description varchar(40) default NULL,
  dn float(10,5) default NULL,
  ds float(10,5) default NULL,
  n float(10,1) default NULL,
  s float(10,1) default NULL,
  lnl float(10,3) default NULL,
  threshold_on_ds float(10,5) default NULL,
  PRIMARY KEY  (homology_id)
) TYPE=MyISAM;
