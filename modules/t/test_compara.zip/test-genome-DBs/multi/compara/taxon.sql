-- MySQL dump 9.11
--
-- Host: ia64f    Database: ensembl_compara_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `taxon`
--

CREATE TABLE taxon (
  taxon_id int(10) NOT NULL default '0',
  genus varchar(50) default NULL,
  species varchar(50) default NULL,
  sub_species varchar(50) default NULL,
  common_name varchar(100) default NULL,
  classification mediumtext,
  PRIMARY KEY  (taxon_id),
  KEY genus (genus,species),
  KEY common_name (common_name)
) TYPE=MyISAM;
