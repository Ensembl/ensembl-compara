# MySQL dump 8.10
#
# Host: ecs1d    Database: arne_compara_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'method_link'
#

CREATE TABLE method_link (
  method_link_id int(10) NOT NULL auto_increment,
  method_link_type varchar(10) DEFAULT '' NOT NULL,
  PRIMARY KEY (method_link_id)
);
