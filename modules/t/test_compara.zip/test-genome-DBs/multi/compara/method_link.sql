-- MySQL dump 9.11
--
-- Host: ia64f    Database: ensembl_compara_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `method_link`
--

CREATE TABLE method_link (
  method_link_id int(10) NOT NULL auto_increment,
  type varchar(50) NOT NULL default '',
  PRIMARY KEY  (method_link_id),
  KEY type (type)
) TYPE=MyISAM;
