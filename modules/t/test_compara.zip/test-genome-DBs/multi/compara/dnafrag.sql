-- MySQL dump 9.11
--
-- Host: ia64f    Database: ensembl_compara_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `dnafrag`
--

CREATE TABLE dnafrag (
  dnafrag_id int(10) NOT NULL auto_increment,
  start int(11) NOT NULL default '0',
  end int(11) NOT NULL default '0',
  name varchar(40) NOT NULL default '',
  genome_db_id int(10) NOT NULL default '0',
  dnafrag_type enum('chromosome','scaffold','supercontig') default NULL,
  PRIMARY KEY  (dnafrag_id),
  UNIQUE KEY name (name,genome_db_id,dnafrag_type),
  KEY dnafrag_id (dnafrag_id,name)
) TYPE=MyISAM;
