# MySQL dump 8.10
#
# Host: ecs1d    Database: arne_compara_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'dnafrag'
#

CREATE TABLE dnafrag (
  dnafrag_id int(10) NOT NULL auto_increment,
  start int(11) DEFAULT '0' NOT NULL,
  end int(11) DEFAULT '0' NOT NULL,
  name varchar(40) DEFAULT '' NOT NULL,
  genome_db_id int(10) DEFAULT '0' NOT NULL,
  dnafrag_type enum('RawContig','Chromosome','VirtualContig'),
  PRIMARY KEY (dnafrag_id),
  KEY dnafrag_id (dnafrag_id,name),
  UNIQUE name (name,genome_db_id,dnafrag_type)
);
