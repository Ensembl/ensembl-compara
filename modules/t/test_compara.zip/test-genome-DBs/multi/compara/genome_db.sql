-- MySQL dump 9.11
--
-- Host: ia64f    Database: ensembl_compara_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `genome_db`
--

CREATE TABLE genome_db (
  genome_db_id int(10) NOT NULL auto_increment,
  taxon_id int(10) NOT NULL default '0',
  name varchar(40) NOT NULL default '',
  assembly varchar(100) NOT NULL default '',
  assembly_default tinyint(1) default '1',
  genebuild varchar(100) NOT NULL default '',
  locator varchar(255) NOT NULL default '',
  PRIMARY KEY  (genome_db_id),
  UNIQUE KEY name (name,assembly,genebuild)
) TYPE=MyISAM;
