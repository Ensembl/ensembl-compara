# MySQL dump 8.10
#
# Host: ecs1d    Database: arne_compara_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'genome_db'
#

CREATE TABLE genome_db (
  genome_db_id int(10) NOT NULL auto_increment,
  taxon_id int(10) DEFAULT '0' NOT NULL,
  name varchar(40) DEFAULT '' NOT NULL,
  locator varchar(255) DEFAULT '' NOT NULL,
  PRIMARY KEY (genome_db_id),
  UNIQUE name (name,locator)
);
