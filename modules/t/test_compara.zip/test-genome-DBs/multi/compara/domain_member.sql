-- MySQL dump 9.11
--
-- Host: ia64f    Database: ensembl_compara_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `domain_member`
--

CREATE TABLE domain_member (
  domain_id int(10) NOT NULL default '0',
  member_id int(10) NOT NULL default '0',
  member_start int(10) default NULL,
  member_end int(10) default NULL,
  UNIQUE KEY domain_id (domain_id,member_id,member_start,member_end),
  UNIQUE KEY member_id (member_id,domain_id,member_start,member_end)
) TYPE=MyISAM;
