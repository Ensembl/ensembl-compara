# MySQL dump 8.10
#
# Host: ecs1d    Database: arne_compara_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'genomic_align_genome'
#

CREATE TABLE genomic_align_genome (
  consensus_genome_db_id int(11) DEFAULT '0' NOT NULL,
  query_genome_db_id int(11) DEFAULT '0' NOT NULL
);
