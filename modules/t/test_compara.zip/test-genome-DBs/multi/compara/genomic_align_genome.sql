-- MySQL dump 9.11
--
-- Host: ia64f    Database: ensembl_compara_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `genomic_align_genome`
--

CREATE TABLE genomic_align_genome (
  consensus_genome_db_id int(11) NOT NULL default '0',
  query_genome_db_id int(11) NOT NULL default '0',
  method_link_id int(10) NOT NULL default '0'
) TYPE=MyISAM;
