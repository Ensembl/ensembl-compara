-- MySQL dump 9.11
--
-- Host: ia64f    Database: rattus_norvegicus_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `coord_system`
--

CREATE TABLE coord_system (
  coord_system_id int(11) NOT NULL auto_increment,
  name varchar(40) NOT NULL default '',
  version varchar(40) default NULL,
  rank int(11) NOT NULL default '0',
  attrib set('default_version','sequence_level') default NULL,
  PRIMARY KEY  (coord_system_id),
  UNIQUE KEY rank (rank),
  UNIQUE KEY name (name,version)
) TYPE=MyISAM;
