-- MySQL dump 9.11
--
-- Host: ia64f    Database: rattus_norvegicus_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `translation_attrib`
--

CREATE TABLE translation_attrib (
  translation_id int(10) unsigned NOT NULL default '0',
  attrib_type_id smallint(5) unsigned NOT NULL default '0',
  value varchar(255) NOT NULL default '',
  KEY type_val_idx (attrib_type_id,value),
  KEY translation_idx (translation_id)
) TYPE=MyISAM;
