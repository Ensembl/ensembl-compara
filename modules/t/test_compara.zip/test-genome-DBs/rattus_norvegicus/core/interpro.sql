-- MySQL dump 9.11
--
-- Host: ia64f    Database: rattus_norvegicus_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `interpro`
--

CREATE TABLE interpro (
  interpro_ac varchar(40) NOT NULL default '',
  id varchar(40) NOT NULL default '',
  KEY interpro_ac (interpro_ac),
  KEY id (id)
) TYPE=MyISAM;
