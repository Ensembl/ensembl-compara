-- MySQL dump 9.11
--
-- Host: ia64f    Database: rattus_norvegicus_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `density_type`
--

CREATE TABLE density_type (
  density_type_id int(11) NOT NULL auto_increment,
  analysis_id int(11) NOT NULL default '0',
  block_size int(11) NOT NULL default '0',
  value_type enum('sum','ratio') NOT NULL default 'sum',
  PRIMARY KEY  (density_type_id),
  UNIQUE KEY analysis_id (analysis_id,block_size)
) TYPE=MyISAM;
