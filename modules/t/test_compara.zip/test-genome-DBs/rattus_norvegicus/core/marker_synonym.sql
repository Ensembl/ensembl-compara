-- MySQL dump 9.11
--
-- Host: ia64f    Database: rattus_norvegicus_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `marker_synonym`
--

CREATE TABLE marker_synonym (
  marker_synonym_id int(10) unsigned NOT NULL auto_increment,
  marker_id int(10) unsigned NOT NULL default '0',
  source varchar(20) default NULL,
  name varchar(30) default NULL,
  PRIMARY KEY  (marker_synonym_id),
  KEY marker_synonym_idx (marker_synonym_id,name),
  KEY marker_idx (marker_id)
) TYPE=MyISAM;
