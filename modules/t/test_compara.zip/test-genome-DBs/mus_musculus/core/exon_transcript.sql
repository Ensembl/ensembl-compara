-- MySQL dump 9.11
--
-- Host: ia64f    Database: mus_musculus_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `exon_transcript`
--

CREATE TABLE exon_transcript (
  exon_id int(10) unsigned NOT NULL default '0',
  transcript_id int(10) unsigned NOT NULL default '0',
  rank int(10) NOT NULL default '0',
  PRIMARY KEY  (exon_id,transcript_id,rank),
  KEY transcript (transcript_id),
  KEY exon (exon_id)
) TYPE=MyISAM;
