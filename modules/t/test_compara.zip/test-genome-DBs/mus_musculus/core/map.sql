-- MySQL dump 9.11
--
-- Host: ia64f    Database: mus_musculus_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `map`
--

CREATE TABLE map (
  map_id int(10) unsigned NOT NULL auto_increment,
  map_name varchar(30) NOT NULL default '',
  PRIMARY KEY  (map_id)
) TYPE=MyISAM;
