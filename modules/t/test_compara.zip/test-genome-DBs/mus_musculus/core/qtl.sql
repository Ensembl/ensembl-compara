-- MySQL dump 9.11
--
-- Host: ia64f    Database: mus_musculus_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `qtl`
--

CREATE TABLE qtl (
  qtl_id int(10) unsigned NOT NULL auto_increment,
  trait varchar(255) NOT NULL default '',
  lod_score float default NULL,
  flank_marker_id_1 int(11) default NULL,
  flank_marker_id_2 int(11) default NULL,
  peak_marker_id int(11) default NULL,
  PRIMARY KEY  (qtl_id),
  KEY trait_idx (trait)
) TYPE=MyISAM;
