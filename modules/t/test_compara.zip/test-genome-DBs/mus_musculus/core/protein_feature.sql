# MySQL dump 8.10
#
# Host: ecs1d    Database: mcvicker_mus_musculus_core_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'protein_feature'
#

CREATE TABLE protein_feature (
  protein_feature_id int(10) unsigned NOT NULL auto_increment,
  translation_id int(11) DEFAULT '0' NOT NULL,
  seq_start int(10) DEFAULT '0' NOT NULL,
  seq_end int(10) DEFAULT '0' NOT NULL,
  analysis_id int(10) unsigned DEFAULT '0' NOT NULL,
  hit_start int(10) DEFAULT '0' NOT NULL,
  hit_end int(10) DEFAULT '0' NOT NULL,
  hit_id varchar(40) DEFAULT '' NOT NULL,
  score double DEFAULT '0' NOT NULL,
  evalue double,
  perc_ident float,
  PRIMARY KEY (protein_feature_id),
  KEY translation_id (translation_id),
  KEY hid_index (hit_id)
);
