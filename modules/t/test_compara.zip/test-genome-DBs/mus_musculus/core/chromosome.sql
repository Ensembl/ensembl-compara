# MySQL dump 8.10
#
# Host: ecs1d    Database: mcvicker_mus_musculus_core_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'chromosome'
#

CREATE TABLE chromosome (
  chromosome_id int(10) unsigned NOT NULL auto_increment,
  name varchar(40) DEFAULT '' NOT NULL,
  known_genes int(11),
  unknown_genes int(11),
  snps int(11),
  length int(11),
  PRIMARY KEY (chromosome_id)
);
