-- MySQL dump 9.11
--
-- Host: ia64f    Database: mus_musculus_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `peptide_archive`
--

CREATE TABLE peptide_archive (
  translation_stable_id varchar(128) NOT NULL default '',
  translation_version smallint(6) NOT NULL default '0',
  peptide_seq mediumtext NOT NULL,
  PRIMARY KEY  (translation_stable_id,translation_version)
) TYPE=MyISAM;
