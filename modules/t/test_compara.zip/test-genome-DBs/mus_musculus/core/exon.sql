-- MySQL dump 9.11
--
-- Host: ia64f    Database: mus_musculus_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `exon`
--

CREATE TABLE exon (
  exon_id int(10) unsigned NOT NULL auto_increment,
  seq_region_id int(10) unsigned NOT NULL default '0',
  seq_region_start int(10) unsigned NOT NULL default '0',
  seq_region_end int(10) unsigned NOT NULL default '0',
  seq_region_strand tinyint(2) NOT NULL default '0',
  phase tinyint(2) NOT NULL default '0',
  end_phase tinyint(2) NOT NULL default '0',
  PRIMARY KEY  (exon_id),
  KEY seq_region_idx (seq_region_id,seq_region_start)
) TYPE=MyISAM;
