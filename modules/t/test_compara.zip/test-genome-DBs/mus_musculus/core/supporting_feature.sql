# MySQL dump 8.10
#
# Host: ecs1d    Database: mcvicker_mus_musculus_core_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'supporting_feature'
#

CREATE TABLE supporting_feature (
  exon_id int(11) DEFAULT '0' NOT NULL,
  feature_type enum('dna_align_feature','protein_align_feature'),
  feature_id int(11) DEFAULT '0' NOT NULL,
  UNIQUE all_idx (exon_id,feature_type,feature_id),
  KEY feature_idx (feature_type,feature_id)
);
