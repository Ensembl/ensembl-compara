-- MySQL dump 9.11
--
-- Host: ia64f    Database: mus_musculus_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `supporting_feature`
--

CREATE TABLE supporting_feature (
  exon_id int(11) NOT NULL default '0',
  feature_type enum('dna_align_feature','protein_align_feature') default NULL,
  feature_id int(11) NOT NULL default '0',
  UNIQUE KEY all_idx (exon_id,feature_type,feature_id),
  KEY feature_idx (feature_type,feature_id)
) TYPE=MyISAM MAX_ROWS=100000000 AVG_ROW_LENGTH=80;
