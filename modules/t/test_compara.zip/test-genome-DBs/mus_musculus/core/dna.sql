-- MySQL dump 9.11
--
-- Host: ia64f    Database: mus_musculus_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `dna`
--

CREATE TABLE dna (
  seq_region_id int(10) unsigned NOT NULL default '0',
  sequence mediumtext NOT NULL,
  PRIMARY KEY  (seq_region_id)
) TYPE=MyISAM MAX_ROWS=750000 AVG_ROW_LENGTH=19000;
