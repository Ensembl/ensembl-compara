-- MySQL dump 9.11
--
-- Host: ia64f    Database: mus_musculus_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `meta_coord`
--

CREATE TABLE meta_coord (
  table_name varchar(40) NOT NULL default '',
  coord_system_id int(11) NOT NULL default '0',
  UNIQUE KEY table_name (table_name,coord_system_id)
) TYPE=MyISAM;
