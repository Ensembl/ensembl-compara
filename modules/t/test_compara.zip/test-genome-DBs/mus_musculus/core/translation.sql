-- MySQL dump 9.11
--
-- Host: ia64f    Database: mus_musculus_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `translation`
--

CREATE TABLE translation (
  translation_id int(10) unsigned NOT NULL auto_increment,
  transcript_id int(10) unsigned NOT NULL default '0',
  seq_start int(10) NOT NULL default '0',
  start_exon_id int(10) unsigned NOT NULL default '0',
  seq_end int(10) NOT NULL default '0',
  end_exon_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (translation_id),
  KEY transcript_id (transcript_id)
) TYPE=MyISAM;
