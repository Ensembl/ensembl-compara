# MySQL dump 8.10
#
# Host: ecs1d    Database: mcvicker_mus_musculus_core_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'repeat_feature'
#

CREATE TABLE repeat_feature (
  repeat_feature_id int(10) unsigned NOT NULL auto_increment,
  contig_id int(10) unsigned DEFAULT '0' NOT NULL,
  contig_start int(10) unsigned DEFAULT '0' NOT NULL,
  contig_end int(10) unsigned DEFAULT '0' NOT NULL,
  contig_strand tinyint(1) DEFAULT '1' NOT NULL,
  analysis_id int(10) unsigned DEFAULT '0' NOT NULL,
  repeat_start int(10) DEFAULT '0' NOT NULL,
  repeat_end int(10) DEFAULT '0' NOT NULL,
  repeat_consensus_id int(10) unsigned DEFAULT '0' NOT NULL,
  score double,
  PRIMARY KEY (repeat_feature_id),
  KEY contig_idx (contig_id,contig_start,analysis_id),
  KEY repeat_idx (repeat_consensus_id,contig_id,contig_start),
  KEY analysis_idx (analysis_id)
);
