# MySQL dump 8.10
#
# Host: ecs1d    Database: mcvicker_homo_sapiens_core_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'prediction_transcript'
#

CREATE TABLE prediction_transcript (
  prediction_transcript_id int(10) unsigned NOT NULL auto_increment,
  exon_rank smallint(5) unsigned DEFAULT '0' NOT NULL,
  contig_id int(10) unsigned DEFAULT '0' NOT NULL,
  contig_start int(10) unsigned DEFAULT '0' NOT NULL,
  contig_end int(10) unsigned DEFAULT '0' NOT NULL,
  contig_strand tinyint(4) DEFAULT '0' NOT NULL,
  start_phase tinyint(4) DEFAULT '0' NOT NULL,
  score double,
  p_value double,
  analysis_id int(11),
  exon_count smallint(6),
  PRIMARY KEY (prediction_transcript_id,exon_rank),
  KEY contig_idx (contig_id,contig_start)
);
