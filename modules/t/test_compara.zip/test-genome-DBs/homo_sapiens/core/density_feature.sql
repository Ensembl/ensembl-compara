-- MySQL dump 9.11
--
-- Host: ia64f    Database: homo_sapiens_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `density_feature`
--

CREATE TABLE density_feature (
  density_feature_id int(11) NOT NULL auto_increment,
  density_type_id int(11) NOT NULL default '0',
  seq_region_id int(11) NOT NULL default '0',
  seq_region_start int(11) NOT NULL default '0',
  seq_region_end int(11) NOT NULL default '0',
  density_value float NOT NULL default '0',
  PRIMARY KEY  (density_feature_id),
  KEY seq_region_idx (density_type_id,seq_region_id,seq_region_start)
) TYPE=MyISAM;
