-- MySQL dump 9.11
--
-- Host: ia64f    Database: homo_sapiens_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `protein_align_feature`
--

CREATE TABLE protein_align_feature (
  protein_align_feature_id int(10) unsigned NOT NULL auto_increment,
  seq_region_id int(10) unsigned NOT NULL default '0',
  seq_region_start int(10) unsigned NOT NULL default '0',
  seq_region_end int(10) unsigned NOT NULL default '0',
  seq_region_strand tinyint(1) NOT NULL default '1',
  hit_start int(10) NOT NULL default '0',
  hit_end int(10) NOT NULL default '0',
  hit_name varchar(40) NOT NULL default '',
  analysis_id int(10) unsigned NOT NULL default '0',
  score double default NULL,
  evalue double default NULL,
  perc_ident float default NULL,
  cigar_line text,
  PRIMARY KEY  (protein_align_feature_id),
  KEY analysis_idx (analysis_id),
  KEY seq_region_idx (seq_region_id,analysis_id,score,seq_region_start),
  KEY hit_idx (hit_name)
) TYPE=MyISAM MAX_ROWS=100000000 AVG_ROW_LENGTH=80;
