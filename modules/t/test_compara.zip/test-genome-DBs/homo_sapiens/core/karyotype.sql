-- MySQL dump 9.11
--
-- Host: ia64f    Database: homo_sapiens_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `karyotype`
--

CREATE TABLE karyotype (
  karyotype_id int(10) unsigned NOT NULL auto_increment,
  seq_region_id int(10) unsigned NOT NULL default '0',
  seq_region_start int(10) NOT NULL default '0',
  seq_region_end int(10) NOT NULL default '0',
  band varchar(40) NOT NULL default '',
  stain varchar(40) NOT NULL default '',
  PRIMARY KEY  (karyotype_id),
  KEY region_band_idx (seq_region_id,band)
) TYPE=MyISAM;
