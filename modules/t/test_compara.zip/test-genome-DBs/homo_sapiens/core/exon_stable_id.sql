-- MySQL dump 9.11
--
-- Host: ia64f    Database: homo_sapiens_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `exon_stable_id`
--

CREATE TABLE exon_stable_id (
  exon_id int(10) unsigned NOT NULL default '0',
  stable_id varchar(128) NOT NULL default '',
  version int(10) default NULL,
  PRIMARY KEY  (exon_id),
  UNIQUE KEY stable_id (stable_id,version)
) TYPE=MyISAM;
