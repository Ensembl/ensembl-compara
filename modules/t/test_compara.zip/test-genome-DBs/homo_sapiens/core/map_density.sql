# MySQL dump 8.10
#
# Host: ecs1d    Database: mcvicker_homo_sapiens_core_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'map_density'
#

CREATE TABLE map_density (
  chromosome_id int(10) unsigned DEFAULT '0' NOT NULL,
  chr_start int(10) DEFAULT '0' NOT NULL,
  chr_end int(10) DEFAULT '0' NOT NULL,
  type varchar(20) DEFAULT '' NOT NULL,
  value int(10) DEFAULT '0' NOT NULL,
  PRIMARY KEY (type,chromosome_id,chr_start)
);
