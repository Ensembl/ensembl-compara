-- MySQL dump 9.11
--
-- Host: ia64f    Database: homo_sapiens_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `object_xref`
--

CREATE TABLE object_xref (
  object_xref_id int(11) NOT NULL auto_increment,
  ensembl_id int(10) unsigned NOT NULL default '0',
  ensembl_object_type enum('RawContig','Transcript','Gene','Translation') NOT NULL default 'RawContig',
  xref_id int(10) unsigned NOT NULL default '0',
  UNIQUE KEY ensembl_object_type (ensembl_object_type,ensembl_id,xref_id),
  KEY oxref_idx (object_xref_id,xref_id,ensembl_object_type,ensembl_id),
  KEY xref_idx (xref_id,ensembl_object_type)
) TYPE=MyISAM;
