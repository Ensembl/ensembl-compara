-- MySQL dump 9.11
--
-- Host: ia64f    Database: homo_sapiens_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `transcript_stable_id`
--

CREATE TABLE transcript_stable_id (
  transcript_id int(10) unsigned NOT NULL default '0',
  stable_id varchar(128) NOT NULL default '',
  version int(10) default NULL,
  PRIMARY KEY  (transcript_id),
  UNIQUE KEY stable_id (stable_id,version)
) TYPE=MyISAM;
