# MySQL dump 8.10
#
# Host: ecs1d    Database: mcvicker_homo_sapiens_core_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'external_db'
#

CREATE TABLE external_db (
  external_db_id int(11) NOT NULL auto_increment,
  db_name enum('gene_name','Celera_Pep','Celera_Trans','Celera_Gene','HumanGenscans','protein_id','SCOP','HUGO','GO','SPTREMBL','EMBL','MarkerSymbol','SWISSPROT','PDB','MIM','RefSeq','LocusLink','Interpro','Superfamily') DEFAULT 'gene_name' NOT NULL,
  release varchar(40) DEFAULT '' NOT NULL,
  status enum('KNOWN','XREF','PRED') DEFAULT 'KNOWN' NOT NULL,
  priority smallint(5) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (external_db_id)
);
