-- MySQL dump 9.11
--
-- Host: ia64f    Database: homo_sapiens_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `gene_description`
--

CREATE TABLE gene_description (
  gene_id int(10) unsigned NOT NULL default '0',
  description text,
  PRIMARY KEY  (gene_id)
) TYPE=MyISAM;
