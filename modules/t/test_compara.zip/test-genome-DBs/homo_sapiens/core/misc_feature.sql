-- MySQL dump 9.11
--
-- Host: ia64f    Database: homo_sapiens_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `misc_feature`
--

CREATE TABLE misc_feature (
  misc_feature_id int(10) unsigned NOT NULL auto_increment,
  seq_region_id int(10) unsigned NOT NULL default '0',
  seq_region_start int(10) unsigned NOT NULL default '0',
  seq_region_end int(10) unsigned NOT NULL default '0',
  seq_region_strand tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (misc_feature_id),
  KEY seq_region_idx (seq_region_id,seq_region_start)
) TYPE=MyISAM;
