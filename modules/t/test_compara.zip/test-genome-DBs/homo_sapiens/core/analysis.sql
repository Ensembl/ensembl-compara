-- MySQL dump 9.11
--
-- Host: ia64f    Database: homo_sapiens_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `analysis`
--

CREATE TABLE analysis (
  analysis_id int(10) unsigned NOT NULL auto_increment,
  created datetime NOT NULL default '0000-00-00 00:00:00',
  logic_name varchar(40) NOT NULL default '',
  db varchar(120) default NULL,
  db_version varchar(40) default NULL,
  db_file varchar(120) default NULL,
  program varchar(80) default NULL,
  program_version varchar(40) default NULL,
  program_file varchar(80) default NULL,
  parameters varchar(255) default NULL,
  module varchar(80) default NULL,
  module_version varchar(40) default NULL,
  gff_source varchar(40) default NULL,
  gff_feature varchar(40) default NULL,
  PRIMARY KEY  (analysis_id),
  UNIQUE KEY logic_name (logic_name),
  KEY logic_name_idx (logic_name)
) TYPE=MyISAM;
