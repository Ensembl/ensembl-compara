-- MySQL dump 9.11
--
-- Host: ia64f    Database: homo_sapiens_core_test
-- ------------------------------------------------------
-- Server version	4.0.20-log

--
-- Table structure for table `external_synonym`
--

CREATE TABLE external_synonym (
  xref_id int(10) unsigned NOT NULL default '0',
  synonym varchar(40) NOT NULL default '',
  PRIMARY KEY  (xref_id,synonym),
  KEY name_index (synonym)
) TYPE=MyISAM;
